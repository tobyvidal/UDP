import threading
import socket
import time

#Hacemos una funcion enviar que envie los mensajes que el cliente desee al servidor, junto a su direccion.
def enviar():
    while True:
        mensaje = input(".").encode("UTF-8")
        if mensaje:
            cliente.sendto("mensaje".encode("UTF-8"), HOST)
            cliente.sendto(mensaje, HOST)

#Hacemos una funcion recibir que reciba todos los mensajes que se envien desde el servidor.
def recibir():
    while True:
        try:
            datos, servidor = cliente.recvfrom(1024)
            print(datos.decode("utf-8"))
        except Exception as e:
            print(f"Error al recibir datos: {e}")
            break

#Creamos la ip, el puerto y con eso creamos el host y por ultimo creamos el socket.
IP = '10.41.25.189'
PUERTO = 9000
HOST = (IP, PUERTO)
cliente = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

#Hacemos el menu de navegacion.
opcion = input("¿Quieres crear un nuevo usuario? (y/n) : ")

#Si el cliente selecciona la opcion 'y', accedera a la opcion de creacion de usuario donde se le pedira un nombre para el mismo,
#una vez el cliente haya puesto un nombre se le enviara al servidor un mensaje con la finalidad de que el servidor sepa lo que estamos
#haciendo y le genere un token al usuario.
if opcion == "y":
    nombre = input("Nombre de usuario : ")
    if nombre:
        cliente.sendto("registro".encode("UTF-8"), HOST)
        cliente.sendto(nombre.encode("UTF-8"), HOST)
#Si el cliente selecciona la opcion 'n' el programa le pedira que ingrese su token de usuario ya existente para poder conectarse al servidor.
elif opcion == "n":
    Token = input("Token : ")
    if Token:
        cliente.sendto("logueo".encode("UTF-8"), HOST)
        cliente.sendto(Token.encode("UTF-8"), HOST)
#Si no selecciona ninguna de las anteriores saldra un mensaje poniendo que los datos han sido erroneos.
else:
    print("Datos erroneos, debe introducir y/n.")

#Creamos los 2 hilos.
hiloRecibir = threading.Thread(target=recibir)
hiloEnviar = threading.Thread(target=enviar)

#Iniciamos los hilos.
hiloRecibir.start()
hiloEnviar.start()