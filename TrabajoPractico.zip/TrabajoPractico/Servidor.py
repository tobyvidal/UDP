#Importamos todo lo que necesitamos.
import socket
import threading
import json
import os
from uuid import uuid4

# Asociamos la variable 'file' al archivo .json que se almacene dentro de nuestra carpeta de trabajo.
file = "TrabajoPractico/Info.json"

# Esta función recibe un token y comprueba si existe en el archivo JSON.
def buscarUsuario(token):
    try:
        with open(file, "r") as f:
            data = json.load(f)
            print(data)
            print(token)

            if token in data:
                return data[token]
            else:
                return None
    except json.decoder.JSONDecodeError:
        return None
    except FileNotFoundError:
        return None

#Funcion logueo: recibe datos del cliente a través del socket del servidor.
#token contiene el token enviado por el cliente y direccion contiene la dirección del cliente.
#Luego en el bloque try except intentamos obtener el cliente con el token asosiado
#Si ocurre alguno de los errores especificados en el except, como ConnectionError, JSONDecodeError, o FileNotFoundError, 
#se manejan en el bloque except, y la función retorna None.
#Por ultimo Se verifica si el nickname obtenido no está presente en los valores del diccionario clientes. 
#Si el nickname no está en clientes, significa que el cliente no está registrado, por lo que se agrega el nickname y 
#el token asociado a los diccionarios clientes y tokens, respectivamente y se le envia al usuario un mensaje de bienvenida.
def logueo():
    token, direccion = servidor.recvfrom(1024)
    try:
        nickname = buscarUsuario(token.decode("UTF-8"))
    except (ConnectionError, json.decoder.JSONDecodeError, FileNotFoundError):
        return None
    
    if nickname not in clientes.values():
        clientes[direccion] = nickname
        tokens[nickname] = token
        servidor.sendto(("Bienvenido al chat!, " + nickname).encode("UTF-8"), direccion)

#Funcion registro: esta funcion espera un mensaje y una direccion el mensaje viene desde la clase clientes, que primero envia
#un mensaje para que el servidor sepa a que funcion deseamos acceder y luego el otro mensaje sera el valor del diccionario token,
#mientras que la direccion sera la clave del diccionario clientes. 
#Tambien esta funcion mediante una libreria genera el token, enviando un mensaje al cliente informando de su token, si no existe el file
#lo crea automaticamente y registra el nuevo usuario.
def registro():
    datos, dirr = servidor.recvfrom(1024)
    clientes[dirr] = datos.decode("UTF-8")
    token = uuid4()
    tokens[datos.decode("UTF-8")] = token
    servidor.sendto(("Tu token de seguridad es : " + str(token)).encode("UTF-8"), dirr)

    if not os.path.exists(file):
        with open(file, "w") as new_file:
            new_file.write("{}")  

    with open(file, "r") as r:
        try:
            data = json.load(r)
        except json.decoder.JSONDecodeError:
            data = dict()  

    data[str(token)] = datos.decode("UTF-8")

    with open(file, "w") as w:
        json.dump(data, w)

#Funcion mensaje: esta funcion espera un mensaje y una direccion, el mensaje viene desde la clase clientes, que primero envia
#un mensaje para que el servidor sepa a que funcion deseamos acceder y luego el otro mensaje sera el que mediante el bucle for, que 
#recorre todo el diccionario de clientes, se envie a todos los clientes del servidor.
def mensaje():
    mensaje, direccion = servidor.recvfrom(2024)   
    for dir in clientes.keys():
        servidor.sendto((clientes[direccion] + ":").encode("utf-8") + mensaje, dir)

# Creamos la IP y el puerto.
IP = '10.41.25.189'
PUERTO = 9000

# Creamos 2 diccionarios que nos ayudaran con el manejo de los clientes (clave/valor).
clientes = dict()
tokens = dict()

# Creamos el socket y le asignamos la dirección.
servidor = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
servidor.bind((IP, PUERTO))

#Hacemos un bucle while que espere constantemente un mensaje y una direccion, dependiendo el mensaje se accedera a una funcion u otra.
while True:
    datos, dirr = servidor.recvfrom(1024)
    dato = datos.decode("UTF-8")

    if dato == "registro":
        registro()
    elif dato == "logueo":
        logueo()
    elif dato == "mensaje":
        threading.Thread(target=mensaje).start()
